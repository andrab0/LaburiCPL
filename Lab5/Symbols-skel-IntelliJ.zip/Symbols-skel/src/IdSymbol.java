public class IdSymbol extends Symbol {
    public IdSymbol(String name) {
        super(name);
    }
};